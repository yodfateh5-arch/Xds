import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { ModelGenerationConfig, Model3DStats, AIAnalysisResult } from '../types';
import { ProcessedImageData, generateVolumetricMesh, generateVoxelMesh } from '../utils/depthEngine';
import { exportGeometryToOBJ, exportGeometryToSTL, triggerFileDownload } from '../utils/export3D';
import {
  RotateCcw,
  Maximize2,
  Minimize2,
  Camera,
  Play,
  Pause,
  Download,
  Box,
  Layers,
  Sparkles,
} from 'lucide-react';

interface ThreeViewerProps {
  processedData: ProcessedImageData | null;
  config: ModelGenerationConfig;
  aiAnalysis: AIAnalysisResult | null;
  onUpdateStats: (stats: Model3DStats) => void;
  onUpdateConfig: (updater: (prev: ModelGenerationConfig) => ModelGenerationConfig) => void;
}

export const ThreeViewer: React.FC<ThreeViewerProps> = ({
  processedData,
  config,
  aiAnalysis,
  onUpdateStats,
  onUpdateConfig,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const currentObjectRef = useRef<THREE.Object3D | null>(null);
  const currentGeometryRef = useRef<THREE.BufferGeometry | null>(null);
  const lightsGroupRef = useRef<THREE.Group | null>(null);

  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  // Initialize Three.js Scene once
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 500;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0e17);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 1.2, 5.5);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      preserveDrawingBuffer: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;

    container.replaceChildren(renderer.domElement);
    rendererRef.current = renderer;

    // Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxDistance = 15;
    controls.minDistance = 1.5;
    controls.target.set(0, 0, 0);
    controlsRef.current = controls;

    // Lights group
    const lightsGroup = new THREE.Group();
    scene.add(lightsGroup);
    lightsGroupRef.current = lightsGroup;

    // Floor Grid & Shadow receiver
    const floorGeo = new THREE.PlaneGeometry(20, 20);
    const floorMat = new THREE.ShadowMaterial({ opacity: 0.35 });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.y = -2.2;
    floorMesh.receiveShadow = true;
    scene.add(floorMesh);

    // Subtle grid helper
    const grid = new THREE.GridHelper(12, 24, 0x3b82f6, 0x1e293b);
    grid.position.y = -2.19;
    scene.add(grid);

    // Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (controlsRef.current) {
        controlsRef.current.autoRotate = config.autoRotate;
        controlsRef.current.autoRotateSpeed = config.rotationSpeed;
        controlsRef.current.update();
      }

      renderer.render(scene, camera);
    };
    animate();

    // Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: newW, height: newH } = entry.contentRect;
        if (newW > 0 && newH > 0) {
          camera.aspect = newW / newH;
          camera.updateProjectionMatrix();
          renderer.setSize(newW, newH);
        }
      }
    });
    resizeObserver.observe(container);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      controls.dispose();
      renderer.dispose();
    };
  }, []);

  // Update Lighting Presets
  useEffect(() => {
    const lightsGroup = lightsGroupRef.current;
    if (!lightsGroup) return;

    lightsGroup.clear();

    if (config.lighting === 'studio') {
      const ambient = new THREE.AmbientLight(0xffffff, 0.7);
      const keyLight = new THREE.DirectionalLight(0xffffff, 1.4);
      keyLight.position.set(4, 6, 5);
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.width = 1024;
      keyLight.shadow.mapSize.height = 1024;

      const fillLight = new THREE.DirectionalLight(0x93c5fd, 0.7);
      fillLight.position.set(-5, 2, 2);

      const rimLight = new THREE.DirectionalLight(0x38bdf8, 1.0);
      rimLight.position.set(0, 4, -5);

      lightsGroup.add(ambient, keyLight, fillLight, rimLight);
    } else if (config.lighting === 'warm') {
      const ambient = new THREE.AmbientLight(0xfef3c7, 0.6);
      const sun = new THREE.DirectionalLight(0xfbbf24, 1.8);
      sun.position.set(5, 5, 4);
      sun.castShadow = true;

      const fill = new THREE.DirectionalLight(0xec4899, 0.6);
      fill.position.set(-4, 2, 2);

      lightsGroup.add(ambient, sun, fill);
    } else if (config.lighting === 'cyber') {
      const ambient = new THREE.AmbientLight(0x1e1b4b, 0.8);
      const cyan = new THREE.DirectionalLight(0x06b6d4, 1.8);
      cyan.position.set(-5, 4, 3);
      cyan.castShadow = true;

      const magenta = new THREE.DirectionalLight(0xd946ef, 1.8);
      magenta.position.set(5, 4, -2);

      lightsGroup.add(ambient, cyan, magenta);
    } else {
      // daylight
      const ambient = new THREE.AmbientLight(0xf8fafc, 1.0);
      const sun = new THREE.DirectionalLight(0xffffff, 1.2);
      sun.position.set(3, 8, 4);
      sun.castShadow = true;
      lightsGroup.add(ambient, sun);
    }
  }, [config.lighting]);

  // Update autoRotate speed dynamically
  useEffect(() => {
    if (controlsRef.current) {
      controlsRef.current.autoRotate = config.autoRotate;
      controlsRef.current.autoRotateSpeed = config.rotationSpeed;
    }
  }, [config.autoRotate, config.rotationSpeed]);

  // Re-build 3D Mesh whenever processedData or geometry-altering config changes
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene || !processedData) return;

    // Remove old 3D object
    if (currentObjectRef.current) {
      scene.remove(currentObjectRef.current);
      if (currentGeometryRef.current) {
        currentGeometryRef.current.dispose();
        currentGeometryRef.current = null;
      }
      currentObjectRef.current = null;
    }

    if (config.mode === 'voxels') {
      const { group, stats } = generateVoxelMesh(processedData, config);
      scene.add(group);
      currentObjectRef.current = group;
      onUpdateStats(stats);
    } else {
      const { mesh, stats } = generateVolumetricMesh(processedData, config, aiAnalysis);
      scene.add(mesh);
      currentObjectRef.current = mesh;
      currentGeometryRef.current = mesh.geometry;
      onUpdateStats(stats);
    }
  }, [
    processedData,
    config.mode,
    config.depthIntensity,
    config.bevelAmount,
    config.doubleSided,
    config.shadingMode,
    config.wireframe,
    aiAnalysis,
  ]);

  // Camera Reset Handler
  const handleResetCamera = () => {
    if (!cameraRef.current || !controlsRef.current) return;
    cameraRef.current.position.set(0, 1.2, 5.5);
    controlsRef.current.target.set(0, 0, 0);
    controlsRef.current.update();
  };

  // Fullscreen Toggle
  const handleToggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  // Take Snapshot
  const handleSnapshot = () => {
    if (!rendererRef.current) return;
    const dataUrl = rendererRef.current.domElement.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `${aiAnalysis?.objectName || '3d_model'}_render.png`;
    link.click();
  };

  // Export OBJ
  const handleExportOBJ = () => {
    if (!currentGeometryRef.current) return;
    setIsExporting(true);
    try {
      const objData = exportGeometryToOBJ(
        currentGeometryRef.current,
        aiAnalysis?.objectName || '3D_Model'
      );
      triggerFileDownload(
        objData,
        `${(aiAnalysis?.objectName || 'model').toLowerCase().replace(/\s+/g, '_')}.obj`,
        'text/plain'
      );
    } finally {
      setIsExporting(false);
    }
  };

  // Export STL (for 3D Printing)
  const handleExportSTL = () => {
    if (!currentGeometryRef.current) return;
    setIsExporting(true);
    try {
      const stlData = exportGeometryToSTL(
        currentGeometryRef.current,
        aiAnalysis?.objectName || '3D_Model'
      );
      triggerFileDownload(
        stlData,
        `${(aiAnalysis?.objectName || 'model').toLowerCase().replace(/\s+/g, '_')}.stl`,
        'model/stl'
      );
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="relative w-full h-[520px] lg:h-[600px] rounded-2xl overflow-hidden bg-[#070a12] border border-slate-800/80 shadow-2xl flex flex-col">
      {/* 3D WebGL Canvas Mount */}
      <div id="threejs-canvas-wrapper" ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Floating Viewport Controls Header */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none z-10">
        {/* Left Badge: Object name and status */}
        <div className="pointer-events-auto flex items-center gap-2 bg-slate-900/85 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-slate-700/60 shadow-lg text-xs font-medium text-slate-200">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold text-white tracking-wide">
            {aiAnalysis?.objectName || '3D Interactive Viewport'}
          </span>
          {aiAnalysis?.category && (
            <span className="text-slate-400 border-l border-slate-700 pl-2">
              {aiAnalysis.category}
            </span>
          )}
        </div>

        {/* Right Action Buttons */}
        <div className="pointer-events-auto flex items-center gap-1.5 bg-slate-900/85 backdrop-blur-md p-1.5 rounded-xl border border-slate-700/60 shadow-lg">
          <button
            id="btn-auto-rotate"
            onClick={() => onUpdateConfig((c) => ({ ...c, autoRotate: !c.autoRotate }))}
            className={`p-2 rounded-lg transition-colors text-xs flex items-center gap-1 ${
              config.autoRotate
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
            title={config.autoRotate ? 'Pause 360° Rotation' : 'Start 360° Rotation'}
          >
            {config.autoRotate ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>

          <button
            id="btn-reset-camera"
            onClick={handleResetCamera}
            className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            title="Reset Camera View"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            id="btn-snapshot"
            onClick={handleSnapshot}
            className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            title="Capture Screenshot PNG"
          >
            <Camera className="w-4 h-4" />
          </button>

          <button
            id="btn-fullscreen"
            onClick={handleToggleFullscreen}
            className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Floating Bottom Toolbar: Shading Modes & Quick Export */}
      <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-center justify-between gap-3 pointer-events-none z-10">
        {/* Shading Style Selector */}
        <div className="pointer-events-auto flex items-center gap-1 bg-slate-900/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-700/60 shadow-lg">
          {(['textured', 'clay', 'normal'] as const).map((mode) => (
            <button
              key={mode}
              id={`btn-shade-${mode}`}
              onClick={() => onUpdateConfig((c) => ({ ...c, shadingMode: mode }))}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-all ${
                config.shadingMode === mode
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {mode}
            </button>
          ))}

          <button
            id="btn-toggle-wireframe"
            onClick={() => onUpdateConfig((c) => ({ ...c, wireframe: !c.wireframe }))}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
              config.wireframe
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
            title="Toggle Wireframe Triangles"
          >
            Wireframe
          </button>
        </div>

        {/* Quick Export Downloads */}
        <div className="pointer-events-auto flex items-center gap-2 bg-slate-900/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-700/60 shadow-lg">
          <button
            id="btn-export-obj"
            onClick={handleExportOBJ}
            disabled={isExporting}
            className="px-3.5 py-1.5 rounded-lg bg-emerald-600/90 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all active:scale-95 disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>.OBJ File</span>
          </button>

          <button
            id="btn-export-stl"
            onClick={handleExportSTL}
            disabled={isExporting}
            className="px-3.5 py-1.5 rounded-lg bg-blue-600/90 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all active:scale-95 disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>.STL (3D Print)</span>
          </button>
        </div>
      </div>

      {/* Floating Instructions Helper in Urdu & English */}
      <div className="absolute top-16 left-4 pointer-events-none z-10 hidden sm:block">
        <div className="bg-slate-900/70 backdrop-blur-sm px-2.5 py-1 rounded-md text-[11px] text-slate-400 border border-slate-800">
          Rotate: Drag Left Click • Pan: Right Click • Zoom: Scroll Wheel
        </div>
      </div>
    </div>
  );
};
