import React, { useRef, useState } from 'react';
import { Upload, Image as ImageIcon, Sparkles, X, CheckCircle2 } from 'lucide-react';
import { SAMPLE_IMAGES } from '../sampleImages';
import { SampleImage } from '../types';

interface UploadZoneProps {
  currentImage: string | null;
  onSelectImage: (dataUrl: string, sampleInfo?: SampleImage) => void;
  isGenerating: boolean;
  onGenerate: () => void;
}

export const UploadZone: React.FC<UploadZoneProps> = ({
  currentImage,
  onSelectImage,
  isGenerating,
  onGenerate,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please upload a valid image file (PNG, JPG, WEBP).');
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        onSelectImage(dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  return (
    <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4 backdrop-blur-sm">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-indigo-400" />
            1. Photo Select / Upload Karein
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Apni image upload karein ya neeche diye gaye samples mein se choose karein
          </p>
        </div>
      </div>

      {/* Upload Drop Zone */}
      <div
        id="image-dropzone"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative group cursor-pointer border-2 border-dashed rounded-xl p-4 transition-all duration-200 flex flex-col items-center justify-center min-h-[170px] ${
          isDragging
            ? 'border-indigo-500 bg-indigo-500/10'
            : currentImage
            ? 'border-slate-700 hover:border-indigo-500/60 bg-slate-950/40'
            : 'border-slate-750 hover:border-indigo-500/60 bg-slate-950/30'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />

        {currentImage ? (
          <div className="relative w-full flex flex-col items-center">
            <div className="relative group/preview max-h-[140px] max-w-[200px] rounded-lg overflow-hidden border border-slate-700 shadow-md">
              <img
                src={currentImage}
                alt="Selected preview"
                className="w-full h-full object-contain bg-slate-950"
              />
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectImage('');
                }}
                className="absolute top-1.5 right-1.5 p-1 bg-slate-900/80 hover:bg-rose-600 text-white rounded-full transition-colors"
                title="Remove photo"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-xs text-indigo-400 mt-2 font-medium flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Photo selected • Click to change
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center text-center">
            <div className="w-12 h-12 rounded-full bg-indigo-600/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mb-2 group-hover:scale-110 transition-transform">
              <Upload className="w-5 h-5" />
            </div>
            <p className="text-sm font-semibold text-slate-200">
              Drag & drop photo here, ya click karein
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Supports PNG, JPG, JPEG, WEBP (Max 50MB)
            </p>
          </div>
        )}
      </div>

      {/* Preset Sample Gallery */}
      <div>
        <span className="text-xs font-semibold text-slate-400 block mb-2">
          Ya foran test karne ke liye sample choose karein:
        </span>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {SAMPLE_IMAGES.map((sample) => {
            const isSelected = currentImage === sample.dataUrl;
            return (
              <button
                key={sample.id}
                type="button"
                id={`btn-sample-${sample.id}`}
                onClick={() => onSelectImage(sample.dataUrl, sample)}
                className={`relative rounded-xl p-1.5 border transition-all text-left group flex flex-col items-center ${
                  isSelected
                    ? 'border-indigo-500 bg-indigo-500/15 shadow-sm ring-1 ring-indigo-500/50'
                    : 'border-slate-800 bg-slate-950/40 hover:border-slate-700 hover:bg-slate-800/40'
                }`}
              >
                <div className="w-full aspect-square rounded-lg overflow-hidden bg-slate-900 flex items-center justify-center p-1">
                  <img
                    src={sample.dataUrl}
                    alt={sample.title}
                    className="w-full h-full object-contain group-hover:scale-105 transition-transform"
                  />
                </div>
                <span className="text-[11px] font-medium text-slate-300 mt-1.5 truncate max-w-full text-center">
                  {sample.title.split(' ')[0]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Generate Button */}
      <button
        id="btn-generate-3d"
        type="button"
        disabled={!currentImage || isGenerating}
        onClick={onGenerate}
        className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-all active:scale-[0.99] ${
          !currentImage
            ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
            : isGenerating
            ? 'bg-indigo-600/70 text-white cursor-wait'
            : 'bg-gradient-to-r from-indigo-600 via-indigo-500 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white shadow-indigo-600/25 border border-indigo-400/30'
        }`}
      >
        <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
        <span>
          {isGenerating
            ? 'Generating 3D Model... (Processing depth & mesh)'
            : 'Generate 3D Model (3D ماڈل بنائیں)'}
        </span>
      </button>
    </div>
  );
};
