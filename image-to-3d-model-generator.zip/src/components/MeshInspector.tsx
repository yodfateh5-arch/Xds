import React from 'react';
import { Model3DStats, AIAnalysisResult } from '../types';
import { Activity, Cpu, Box, Palette, Info, Check } from 'lucide-react';

interface MeshInspectorProps {
  stats: Model3DStats | null;
  aiAnalysis: AIAnalysisResult | null;
}

export const MeshInspector: React.FC<MeshInspectorProps> = ({ stats, aiAnalysis }) => {
  return (
    <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5 shadow-xl backdrop-blur-sm flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400" />
          3D Mesh Inspector & AI Diagnostics
        </h3>
        <span className="text-[11px] text-emerald-400 font-medium px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-1">
          <Check className="w-3 h-3" /> Ready
        </span>
      </div>

      {/* AI Semantic Detection Card */}
      {aiAnalysis && (
        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-indigo-300 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5" /> AI Vision Analysis
            </span>
            <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded">
              Gemini Vision
            </span>
          </div>
          <div className="text-sm font-bold text-white">
            {aiAnalysis.objectName}
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {aiAnalysis.description}
          </p>

          <div className="grid grid-cols-3 gap-2 mt-1 pt-2 border-t border-slate-800/80 text-[11px]">
            <div>
              <span className="text-slate-400 block">Shape Type:</span>
              <span className="font-semibold text-slate-200 capitalize">{aiAnalysis.shapeType}</span>
            </div>
            <div>
              <span className="text-slate-400 block">Symmetry:</span>
              <span className="font-semibold text-slate-200 capitalize">{aiAnalysis.symmetry}</span>
            </div>
            <div>
              <span className="text-slate-400 block">PBR Roughness:</span>
              <span className="font-semibold text-slate-200">{aiAnalysis.roughness}</span>
            </div>
          </div>

          {/* Extracted Colors */}
          {aiAnalysis.dominantColors && aiAnalysis.dominantColors.length > 0 && (
            <div className="flex items-center gap-1.5 mt-1">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 mr-1">
                <Palette className="w-3 h-3 text-slate-400" /> Palette:
              </span>
              {aiAnalysis.dominantColors.map((color, idx) => (
                <div
                  key={idx}
                  className="w-4 h-4 rounded-full border border-slate-700 shadow-sm"
                  style={{ backgroundColor: color }}
                  title={color}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Technical Geometry Statistics */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800">
            <span className="text-[11px] text-slate-400 block font-medium">Vertices (نکات)</span>
            <span className="text-base font-bold font-mono text-white mt-0.5 block">
              {stats.verticesCount.toLocaleString()}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800">
            <span className="text-[11px] text-slate-400 block font-medium">Triangles / Faces</span>
            <span className="text-base font-bold font-mono text-indigo-400 mt-0.5 block">
              {stats.trianglesCount.toLocaleString()}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800">
            <span className="text-[11px] text-slate-400 block font-medium">Size (X × Y × Z)</span>
            <span className="text-xs font-bold font-mono text-slate-200 mt-1 block">
              {stats.width} × {stats.height} × {stats.depth}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800">
            <span className="text-[11px] text-slate-400 block font-medium">Est. 3D Print Mass</span>
            <span className="text-base font-bold font-mono text-emerald-400 mt-0.5 block">
              ~{stats.estimatedPrintWeightGram || 12}g
            </span>
          </div>
        </div>
      )}

      {/* Export Format Info Box */}
      <div className="p-3 rounded-xl bg-indigo-950/20 border border-indigo-900/40 text-xs text-indigo-300/90 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-white block">Export Compatibility:</strong>
          .OBJ files can be imported into Blender, Unreal Engine, Maya & Unity. .STL files can be opened in Cura or PrusaSlicer for direct 3D printing.
        </div>
      </div>
    </div>
  );
};
