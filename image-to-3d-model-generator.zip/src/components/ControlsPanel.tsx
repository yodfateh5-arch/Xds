import React from 'react';
import { ModelGenerationConfig, MeshMode, LightingPreset } from '../types';
import { Sliders, Sun, Cuboid, Layers, Compass } from 'lucide-react';

interface ControlsPanelProps {
  config: ModelGenerationConfig;
  onChangeConfig: (updater: (prev: ModelGenerationConfig) => ModelGenerationConfig) => void;
}

export const ControlsPanel: React.FC<ControlsPanelProps> = ({ config, onChangeConfig }) => {
  const modes: { id: MeshMode; label: string; desc: string }[] = [
    {
      id: 'volumetric',
      label: 'Volumetric Solid',
      desc: 'Complete watertight 3D mesh with front, back bevel, and side walls',
    },
    {
      id: 'relief',
      label: 'Organic Relief',
      desc: 'High-definition single-sided sculpted surface',
    },
    {
      id: 'voxels',
      label: '3D Voxels',
      desc: 'Stylized 3D cubic voxel sculpture',
    },
    {
      id: 'lowpoly',
      label: 'Low-Poly Mesh',
      desc: 'Faceted geometric polygon aesthetic',
    },
  ];

  const lightingPresets: { id: LightingPreset; label: string }[] = [
    { id: 'studio', label: 'Studio' },
    { id: 'warm', label: 'Sunset' },
    { id: 'cyber', label: 'Neon' },
    { id: 'daylight', label: 'Daylight' },
  ];

  return (
    <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5 shadow-xl backdrop-blur-sm flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Sliders className="w-4 h-4 text-indigo-400" />
          3D Model Settings & Controls
        </h3>
        <span className="text-xs text-slate-400">Real-time update</span>
      </div>

      {/* Mode Selection */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
          <Cuboid className="w-3.5 h-3.5 text-indigo-400" /> 3D Mesh Type:
        </label>
        <div className="grid grid-cols-2 gap-2">
          {modes.map((m) => (
            <button
              key={m.id}
              id={`mode-${m.id}`}
              type="button"
              onClick={() => onChangeConfig((c) => ({ ...c, mode: m.id }))}
              className={`p-2.5 rounded-xl border text-left transition-all ${
                config.mode === m.id
                  ? 'border-indigo-500 bg-indigo-500/15 ring-1 ring-indigo-500/40'
                  : 'border-slate-800 bg-slate-950/40 hover:border-slate-700 hover:bg-slate-800/40'
              }`}
            >
              <div className="text-xs font-bold text-white">{m.label}</div>
              <div className="text-[10px] text-slate-400 leading-tight mt-0.5">{m.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Depth Intensity Slider */}
      <div className="flex flex-col gap-1.5">
        <div className="flex justify-between text-xs font-medium">
          <span className="text-slate-300">Depth Extrusion (موٹائی / گہرائی):</span>
          <span className="text-indigo-400 font-mono font-bold">{config.depthIntensity.toFixed(1)}x</span>
        </div>
        <input
          id="slider-depth"
          type="range"
          min="0.3"
          max="2.5"
          step="0.1"
          value={config.depthIntensity}
          onChange={(e) => {
            const val = parseFloat(e.target.value);
            onChangeConfig((c) => ({ ...c, depthIntensity: val }));
          }}
          className="w-full accent-indigo-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-slate-500">
          <span>Flat</span>
          <span>Balanced (1.0x)</span>
          <span>Deep 3D</span>
        </div>
      </div>

      {/* Bevel Curvature Slider (for Volumetric mode) */}
      {config.mode !== 'voxels' && (
        <div className="flex flex-col gap-1.5">
          <div className="flex justify-between text-xs font-medium">
            <span className="text-slate-300">Curvature & Bevel (گولائی):</span>
            <span className="text-indigo-400 font-mono font-bold">{config.bevelAmount.toFixed(2)}</span>
          </div>
          <input
            id="slider-bevel"
            type="range"
            min="0.1"
            max="0.8"
            step="0.05"
            value={config.bevelAmount}
            onChange={(e) => {
              const val = parseFloat(e.target.value);
              onChangeConfig((c) => ({ ...c, bevelAmount: val }));
            }}
            className="w-full accent-indigo-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
          />
        </div>
      )}

      {/* Double-Sided Watertight Toggle */}
      {config.mode !== 'voxels' && (
        <label className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/40 border border-slate-800/80 cursor-pointer hover:border-slate-700">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-indigo-400" />
            <div>
              <div className="text-xs font-semibold text-white">Double-Sided Watertight</div>
              <div className="text-[10px] text-slate-400">Creates back face & connecting rim (3D printable)</div>
            </div>
          </div>
          <input
            type="checkbox"
            id="checkbox-doublesided"
            checked={config.doubleSided}
            onChange={(e) => {
              const checked = e.target.checked;
              onChangeConfig((c) => ({ ...c, doubleSided: checked }));
            }}
            className="w-4 h-4 accent-indigo-600 rounded cursor-pointer"
          />
        </label>
      )}

      {/* Lighting Preset Selector */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
          <Sun className="w-3.5 h-3.5 text-amber-400" /> Lighting Environment:
        </label>
        <div className="grid grid-cols-4 gap-1.5">
          {lightingPresets.map((preset) => (
            <button
              key={preset.id}
              id={`light-${preset.id}`}
              type="button"
              onClick={() => onChangeConfig((c) => ({ ...c, lighting: preset.id }))}
              className={`py-1.5 px-2 rounded-lg text-xs font-medium transition-all ${
                config.lighting === preset.id
                  ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                  : 'bg-slate-950/60 text-slate-400 hover:text-slate-200 border border-slate-800 hover:border-slate-700'
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {/* Rotation Speed Slider */}
      <div className="flex flex-col gap-1.5">
        <div className="flex justify-between text-xs font-medium">
          <span className="text-slate-300 flex items-center gap-1">
            <Compass className="w-3 h-3 text-indigo-400" /> Rotation Speed:
          </span>
          <span className="text-indigo-400 font-mono font-bold">{config.rotationSpeed.toFixed(1)}x</span>
        </div>
        <input
          id="slider-rotation-speed"
          type="range"
          min="0.5"
          max="3.0"
          step="0.5"
          value={config.rotationSpeed}
          onChange={(e) => {
            const val = parseFloat(e.target.value);
            onChangeConfig((c) => ({ ...c, rotationSpeed: val }));
          }}
          className="w-full accent-indigo-500 bg-slate-800 h-1.5 rounded-lg cursor-pointer"
        />
      </div>
    </div>
  );
};
