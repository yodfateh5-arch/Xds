import { SampleImage } from './types';

// Helper to create clean base64 SVG data URLs
function svgToDataUrl(svgString: string): string {
  try {
    return `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(svgString.trim())))}`;
  } catch {
    return `data:image/svg+xml;utf8,${encodeURIComponent(svgString.trim())}`;
  }
}

export const SAMPLE_IMAGES: SampleImage[] = [
  {
    id: 'mug',
    title: 'Ceramic Coffee Mug',
    titleUrdu: 'کافی کا کپ (Coffee Mug)',
    category: 'Pottery / Household',
    dataUrl: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
        <defs>
          <radialGradient id="bgGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="#1e293b"/>
            <stop offset="100%" stop-color="#0f172a"/>
          </radialGradient>
          <linearGradient id="mugGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#38bdf8"/>
            <stop offset="40%" stop-color="#0284c7"/>
            <stop offset="100%" stop-color="#0369a1"/>
          </linearGradient>
          <linearGradient id="coffeeGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#3e2723"/>
            <stop offset="100%" stop-color="#5d4037"/>
          </linearGradient>
          <linearGradient id="handleGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#0284c7"/>
            <stop offset="100%" stop-color="#38bdf8"/>
          </linearGradient>
          <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="16" stdDeviation="14" flood-color="#000000" flood-opacity="0.6"/>
          </filter>
        </defs>
        <rect width="400" height="400" fill="url(#bgGlow)"/>
        <!-- Table shadow -->
        <ellipse cx="200" cy="330" rx="110" ry="24" fill="#000000" opacity="0.4"/>
        <!-- Mug Handle -->
        <path d="M 270 170 C 340 170 340 280 270 280 L 255 260 C 300 260 300 190 255 190 Z" fill="url(#handleGrad)" filter="url(#shadow)"/>
        <!-- Mug Body -->
        <path d="M 120 150 C 120 150 115 310 135 320 C 155 330 245 330 265 320 C 285 310 280 150 280 150 Z" fill="url(#mugGrad)" filter="url(#shadow)"/>
        <!-- Rim -->
        <ellipse cx="200" cy="150" rx="80" ry="24" fill="#e0f2fe"/>
        <!-- Inside / Coffee -->
        <ellipse cx="200" cy="153" rx="72" ry="20" fill="url(#coffeeGrad)"/>
        <ellipse cx="200" cy="154" rx="60" ry="14" fill="#6f4e37" opacity="0.8"/>
        <!-- Highlights -->
        <path d="M 140 170 Q 135 240 145 300" stroke="#bae6fd" stroke-width="8" stroke-linecap="round" fill="none" opacity="0.6"/>
      </svg>
    `),
  },
  {
    id: 'chair',
    title: 'Nordic Wooden Chair',
    titleUrdu: 'لکڑی کی کرسی (Wooden Chair)',
    category: 'Furniture',
    dataUrl: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
        <defs>
          <radialGradient id="bg2" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="#1e293b"/>
            <stop offset="100%" stop-color="#090d16"/>
          </radialGradient>
          <linearGradient id="woodGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#f59e0b"/>
            <stop offset="50%" stop-color="#d97706"/>
            <stop offset="100%" stop-color="#b45309"/>
          </linearGradient>
          <linearGradient id="cushionGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#475569"/>
            <stop offset="100%" stop-color="#1e293b"/>
          </linearGradient>
        </defs>
        <rect width="400" height="400" fill="url(#bg2)"/>
        <!-- Shadow -->
        <ellipse cx="200" cy="350" rx="100" ry="18" fill="#000" opacity="0.5"/>
        <!-- Back Legs -->
        <path d="M 150 240 L 135 345" stroke="#92400e" stroke-width="12" stroke-linecap="round"/>
        <path d="M 250 240 L 265 345" stroke="#92400e" stroke-width="12" stroke-linecap="round"/>
        <!-- Backrest -->
        <path d="M 150 100 C 170 85 230 85 250 100 L 245 220 L 155 220 Z" fill="url(#woodGrad)"/>
        <ellipse cx="200" cy="140" rx="25" ry="15" fill="#1e293b" opacity="0.3"/>
        <!-- Seat -->
        <ellipse cx="200" cy="235" rx="85" ry="25" fill="url(#cushionGrad)"/>
        <ellipse cx="200" cy="232" rx="80" ry="20" fill="#334155"/>
        <!-- Front Legs -->
        <path d="M 140 245 L 125 350" stroke="#b45309" stroke-width="14" stroke-linecap="round"/>
        <path d="M 260 245 L 275 350" stroke="#b45309" stroke-width="14" stroke-linecap="round"/>
      </svg>
    `),
  },
  {
    id: 'apple',
    title: 'Fresh Red Apple',
    titleUrdu: 'تازہ سیب (Fresh Apple)',
    category: 'Nature / Fruit',
    dataUrl: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
        <defs>
          <radialGradient id="appleGrad" cx="35%" cy="35%" r="65%">
            <stop offset="0%" stop-color="#ff7b72"/>
            <stop offset="30%" stop-color="#ef4444"/>
            <stop offset="75%" stop-color="#b91c1c"/>
            <stop offset="100%" stop-color="#7f1d1d"/>
          </radialGradient>
          <linearGradient id="leafGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#86efac"/>
            <stop offset="100%" stop-color="#15803d"/>
          </linearGradient>
        </defs>
        <rect width="400" height="400" fill="#0b0f19"/>
        <ellipse cx="200" cy="335" rx="90" ry="20" fill="#000" opacity="0.6"/>
        <!-- Stem -->
        <path d="M 200 135 C 205 100 220 80 235 75" stroke="#78350f" stroke-width="8" stroke-linecap="round" fill="none"/>
        <!-- Leaf -->
        <path d="M 215 95 C 245 80 265 95 260 115 C 235 125 220 115 215 95 Z" fill="url(#leafGrad)"/>
        <!-- Apple Body -->
        <path d="M 200 145 C 160 120 110 140 105 190 C 100 240 120 310 170 325 C 190 330 200 320 200 320 C 200 320 210 330 230 325 C 280 310 300 240 295 190 C 290 140 240 120 200 145 Z" fill="url(#appleGrad)"/>
        <!-- Highlight -->
        <ellipse cx="150" cy="180" rx="25" ry="40" fill="#ffffff" opacity="0.35" transform="rotate(-20 150 180)"/>
      </svg>
    `),
  },
  {
    id: 'sneaker',
    title: 'Athletic Sneaker',
    titleUrdu: 'اسپورٹس جوتا (Sneaker)',
    category: 'Footwear / Fashion',
    dataUrl: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
        <defs>
          <linearGradient id="soleGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stop-color="#f8fafc"/>
            <stop offset="100%" stop-color="#cbd5e1"/>
          </linearGradient>
          <linearGradient id="bodyGrad" x1="0%" y1="0%" x2="100%" y2="50%">
            <stop offset="0%" stop-color="#6366f1"/>
            <stop offset="50%" stop-color="#4338ca"/>
            <stop offset="100%" stop-color="#312e81"/>
          </linearGradient>
        </defs>
        <rect width="400" height="400" fill="#0b0f19"/>
        <ellipse cx="200" cy="320" rx="140" ry="18" fill="#000" opacity="0.5"/>
        <!-- Sole -->
        <path d="M 60 270 Q 120 275 220 270 Q 320 260 340 245 L 340 290 Q 220 300 60 290 Z" fill="url(#soleGrad)"/>
        <path d="M 60 290 Q 220 305 340 295 L 340 305 Q 220 315 60 305 Z" fill="#0f172a"/>
        <!-- Upper -->
        <path d="M 70 270 C 65 220 110 180 150 175 L 190 140 C 210 135 235 150 235 180 L 260 200 L 325 235 C 340 245 340 255 335 260 Z" fill="url(#bodyGrad)"/>
        <!-- Swoosh / Stripe -->
        <path d="M 120 230 Q 180 250 260 190 Q 200 240 140 235 Z" fill="#38bdf8"/>
        <!-- Laces -->
        <line x1="180" y1="160" x2="200" y2="175" stroke="#f1f5f9" stroke-width="4" stroke-linecap="round"/>
        <line x1="190" y1="180" x2="215" y2="195" stroke="#f1f5f9" stroke-width="4" stroke-linecap="round"/>
        <line x1="205" y1="200" x2="230" y2="215" stroke="#f1f5f9" stroke-width="4" stroke-linecap="round"/>
      </svg>
    `),
  },
  {
    id: 'camera',
    title: 'Vintage Film Camera',
    titleUrdu: 'کیمرہ (Vintage Camera)',
    category: 'Electronics / Retro',
    dataUrl: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
        <defs>
          <linearGradient id="camMetal" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#94a3b8"/>
            <stop offset="50%" stop-color="#e2e8f0"/>
            <stop offset="100%" stop-color="#64748b"/>
          </linearGradient>
          <linearGradient id="camLens" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="#0284c7"/>
            <stop offset="40%" stop-color="#0369a1"/>
            <stop offset="80%" stop-color="#082f49"/>
            <stop offset="100%" stop-color="#0f172a"/>
          </linearGradient>
        </defs>
        <rect width="400" height="400" fill="#0b0f19"/>
        <ellipse cx="200" cy="325" rx="120" ry="18" fill="#000" opacity="0.5"/>
        <!-- Top plate -->
        <rect x="90" y="140" width="220" height="35" rx="6" fill="url(#camMetal)"/>
        <!-- Dials and Shutter -->
        <rect x="110" y="125" width="28" height="15" rx="3" fill="#cbd5e1"/>
        <rect x="255" y="128" width="35" height="12" rx="3" fill="#cbd5e1"/>
        <!-- Body -->
        <rect x="90" y="175" width="220" height="120" rx="8" fill="#1e293b"/>
        <!-- Leather grip strip -->
        <rect x="90" y="185" width="220" height="100" fill="#0f172a"/>
        <!-- Lens Outer Ring -->
        <circle cx="200" cy="235" r="55" fill="url(#camMetal)"/>
        <circle cx="200" cy="235" r="46" fill="#0f172a"/>
        <!-- Lens Glass -->
        <circle cx="200" cy="235" r="38" fill="#0369a1"/>
        <circle cx="200" cy="235" r="30" fill="#0c4a6e"/>
        <!-- Lens Reflection -->
        <ellipse cx="185" cy="220" rx="14" ry="8" fill="#38bdf8" opacity="0.6" transform="rotate(-30 185 220)"/>
      </svg>
    `),
  },
  {
    id: 'ring',
    title: 'Emerald Gold Ring',
    titleUrdu: 'سونے کی انگوٹھی (Gold Ring)',
    category: 'Jewelry / Luxury',
    dataUrl: svgToDataUrl(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400" width="400" height="400">
        <defs>
          <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#fef08a"/>
            <stop offset="35%" stop-color="#eab308"/>
            <stop offset="70%" stop-color="#ca8a04"/>
            <stop offset="100%" stop-color="#854d0e"/>
          </linearGradient>
          <linearGradient id="gemGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#6ee7b7"/>
            <stop offset="50%" stop-color="#10b981"/>
            <stop offset="100%" stop-color="#047857"/>
          </linearGradient>
        </defs>
        <rect width="400" height="400" fill="#0b0f19"/>
        <ellipse cx="200" cy="330" rx="100" ry="16" fill="#000" opacity="0.5"/>
        <!-- Back of band -->
        <ellipse cx="200" cy="210" rx="80" ry="60" fill="none" stroke="#ca8a04" stroke-width="20"/>
        <!-- Gem Mount -->
        <polygon points="175,130 225,130 240,165 160,165" fill="#facc15"/>
        <!-- Emerald Gemstone -->
        <polygon points="180,105 220,105 245,140 200,165 155,140" fill="url(#gemGrad)"/>
        <polygon points="180,105 220,105 200,135" fill="#a7f3d0" opacity="0.7"/>
        <!-- Front of band -->
        <path d="M 120 210 C 120 270 280 270 280 210" fill="none" stroke="url(#goldGrad)" stroke-width="22" stroke-linecap="round"/>
      </svg>
    `),
  },
];
