import React, { useState, useEffect } from 'react';
import { Box, Sparkles, HelpCircle, Layers, RefreshCw, Eye } from 'lucide-react';
import { UploadZone } from './components/UploadZone';
import { ThreeViewer } from './components/ThreeViewer';
import { ControlsPanel } from './components/ControlsPanel';
import { MeshInspector } from './components/MeshInspector';
import { SAMPLE_IMAGES } from './sampleImages';
import {
  ModelGenerationConfig,
  Model3DStats,
  AIAnalysisResult,
  SampleImage,
} from './types';
import { processImageForDepth, ProcessedImageData, rasterizeImageToBase64 } from './utils/depthEngine';

export default function App() {
  const [currentImage, setCurrentImage] = useState<string>(SAMPLE_IMAGES[0].dataUrl);
  const [processedData, setProcessedData] = useState<ProcessedImageData | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult | null>(null);
  const [stats, setStats] = useState<Model3DStats | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generationStep, setGenerationStep] = useState<string>('');

  const [config, setConfig] = useState<ModelGenerationConfig>({
    mode: 'volumetric',
    depthIntensity: 1.2,
    bevelAmount: 0.35,
    meshResolution: 'high',
    doubleSided: true,
    wireframe: false,
    shadingMode: 'textured',
    lighting: 'studio',
    autoRotate: true,
    rotationSpeed: 1.5,
  });

  // Generate 3D model from image
  const generateModel = async (imageSrc: string) => {
    if (!imageSrc) return;
    setIsGenerating(true);
    setGenerationStep('AI Vision سے تصویر کی ساخت سمجھ رہے ہیں...');

    try {
      // 1. Rasterize image to standard clean JPEG Base64 for AI vision analysis
      const { base64: rasterBase64, mimeType: rasterMime } = await rasterizeImageToBase64(imageSrc);

      let aiResult: AIAnalysisResult | null = null;
      if (rasterBase64) {
        try {
          const res = await fetch('/api/generate-3d', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              image: rasterBase64,
              mimeType: rasterMime,
              mode: config.mode,
            }),
          });

          if (res.ok) {
            const data = await res.json();
            if (data.analysis) {
              aiResult = data.analysis;
            }
          }
        } catch (err) {
          console.warn('API error, proceeding with client-side vision processing:', err);
        }
      }

      setGenerationStep('Depth map اور 3D Geometry بنا رہے ہیں...');

      // 2. Process image depth and normals
      const processed = await processImageForDepth(imageSrc, config.meshResolution);

      setGenerationStep('3D Mesh اور PBR Shaders رینڈر ہو رہے ہیں...');

      setAiAnalysis(aiResult);
      setProcessedData(processed);
    } catch (err: any) {
      console.error('Failed to generate 3D model:', err);
      alert('Error generating 3D model: ' + (err?.message || 'Unknown error'));
    } finally {
      setIsGenerating(false);
      setGenerationStep('');
    }
  };

  // Initial load: generate model for default sample image
  useEffect(() => {
    generateModel(SAMPLE_IMAGES[0].dataUrl);
  }, []);

  const handleSelectImage = (dataUrl: string, sample?: SampleImage) => {
    setCurrentImage(dataUrl);
    if (dataUrl) {
      // If sample was selected, auto trigger generation
      generateModel(dataUrl);
    } else {
      setProcessedData(null);
    }
  };

  const handleManualGenerate = () => {
    if (currentImage) {
      generateModel(currentImage);
    }
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Top Header */}
      <header className="border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md sticky top-0 z-30 px-4 lg:px-8 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center shadow-lg shadow-indigo-600/30">
              <Box className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-extrabold text-white tracking-tight">
                  Image to 3D Model Generator
                </h1>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  AI Computer Vision
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Photo dal kar generate dabayein • 3D model ban jaega
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2 text-xs text-slate-400 bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded-lg">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>OBJ & STL (3D Print Ready)</span>
            </div>

            <button
              id="btn-re-generate"
              onClick={handleManualGenerate}
              disabled={isGenerating || !currentImage}
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-lg border border-slate-800 transition-colors disabled:opacity-50"
              title="Regenerate 3D Model"
            >
              <RefreshCw className={`w-4 h-4 ${isGenerating ? 'animate-spin text-indigo-400' : ''}`} />
            </button>
          </div>
        </div>
      </header>

      {/* Generation Progress Banner */}
      {isGenerating && (
        <div className="bg-indigo-600/20 border-b border-indigo-500/30 px-4 py-2 text-center text-xs font-semibold text-indigo-200 flex items-center justify-center gap-2 animate-pulse">
          <Sparkles className="w-4 h-4 text-indigo-400 animate-spin" />
          <span>{generationStep || 'Generating 3D model...'}</span>
        </div>
      )}

      {/* Main Content Layout */}
      <main className="max-w-7xl mx-auto w-full p-4 lg:p-6 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Upload Photo & Generation Controls */}
        <div className="lg:col-span-5 flex flex-col gap-6 order-2 lg:order-1">
          {/* Step 1: Upload / Pick Image */}
          <UploadZone
            currentImage={currentImage}
            onSelectImage={handleSelectImage}
            isGenerating={isGenerating}
            onGenerate={handleManualGenerate}
          />

          {/* Step 2: 3D Model Customization & Controls */}
          <ControlsPanel config={config} onChangeConfig={setConfig} />
        </div>

        {/* Right Column: Interactive 3D Viewport & Diagnostics */}
        <div className="lg:col-span-7 flex flex-col gap-6 order-1 lg:order-2">
          {/* 3D WebGL Canvas */}
          <ThreeViewer
            processedData={processedData}
            config={config}
            aiAnalysis={aiAnalysis}
            onUpdateStats={setStats}
            onUpdateConfig={setConfig}
          />

          {/* Technical Diagnostics & AI Insights */}
          <MeshInspector stats={stats} aiAnalysis={aiAnalysis} />
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/60 px-4 py-4 text-center text-xs text-slate-500">
        <p>
          Image to 3D Model Generator • Rotate with mouse drag • Zoom with scroll • Export to .OBJ & .STL
        </p>
      </footer>
    </div>
  );
}
