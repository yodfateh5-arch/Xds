import * as THREE from 'three';

/**
 * Converts a Three.js BufferGeometry to Wavefront .OBJ string
 */
export function exportGeometryToOBJ(geometry: THREE.BufferGeometry, objectName = '3D_Model'): string {
  const posAttr = geometry.getAttribute('position');
  const uvAttr = geometry.getAttribute('uv');
  const normAttr = geometry.getAttribute('normal');
  const indexAttr = geometry.getIndex();

  let objOutput = `# Exported from Image-to-3D Model Generator\n`;
  objOutput += `o ${objectName.replace(/[^a-zA-Z0-9_]/g, '_')}\n`;

  // Vertices (v x y z)
  for (let i = 0; i < posAttr.count; i++) {
    const x = posAttr.getX(i).toFixed(4);
    const y = posAttr.getY(i).toFixed(4);
    const z = posAttr.getZ(i).toFixed(4);
    objOutput += `v ${x} ${y} ${z}\n`;
  }

  // UV coordinates (vt u v)
  if (uvAttr) {
    for (let i = 0; i < uvAttr.count; i++) {
      const u = uvAttr.getX(i).toFixed(4);
      const v = uvAttr.getY(i).toFixed(4);
      objOutput += `vt ${u} ${v}\n`;
    }
  }

  // Normals (vn x y z)
  if (normAttr) {
    for (let i = 0; i < normAttr.count; i++) {
      const nx = normAttr.getX(i).toFixed(4);
      const ny = normAttr.getY(i).toFixed(4);
      const nz = normAttr.getZ(i).toFixed(4);
      objOutput += `vn ${nx} ${ny} ${nz}\n`;
    }
  }

  objOutput += `s 1\n`;

  // Faces (f v1/vt1/vn1 v2/vt2/vn2 v3/vt3/vn3)
  if (indexAttr) {
    for (let i = 0; i < indexAttr.count; i += 3) {
      const a = indexAttr.getX(i) + 1;
      const b = indexAttr.getX(i + 1) + 1;
      const c = indexAttr.getX(i + 2) + 1;

      if (uvAttr && normAttr) {
        objOutput += `f ${a}/${a}/${a} ${b}/${b}/${b} ${c}/${c}/${c}\n`;
      } else if (normAttr) {
        objOutput += `f ${a}//${a} ${b}//${b} ${c}//${c}\n`;
      } else {
        objOutput += `f ${a} ${b} ${c}\n`;
      }
    }
  } else {
    for (let i = 0; i < posAttr.count; i += 3) {
      const a = i + 1;
      const b = i + 2;
      const c = i + 3;
      if (uvAttr && normAttr) {
        objOutput += `f ${a}/${a}/${a} ${b}/${b}/${b} ${c}/${c}/${c}\n`;
      } else {
        objOutput += `f ${a} ${b} ${c}\n`;
      }
    }
  }

  return objOutput;
}

/**
 * Converts a Three.js BufferGeometry to ASCII STL string for 3D printing
 */
export function exportGeometryToSTL(geometry: THREE.BufferGeometry, objectName = '3D_Model'): string {
  const posAttr = geometry.getAttribute('position');
  const normAttr = geometry.getAttribute('normal');
  const indexAttr = geometry.getIndex();

  let stl = `solid ${objectName.replace(/[^a-zA-Z0-9_]/g, '_')}\n`;

  const getVertex = (idx: number) => {
    return `${posAttr.getX(idx).toFixed(4)} ${posAttr.getY(idx).toFixed(4)} ${posAttr.getZ(idx).toFixed(4)}`;
  };

  const getNormal = (idx: number) => {
    if (!normAttr) return '0.0 0.0 1.0';
    return `${normAttr.getX(idx).toFixed(4)} ${normAttr.getY(idx).toFixed(4)} ${normAttr.getZ(idx).toFixed(4)}`;
  };

  if (indexAttr) {
    for (let i = 0; i < indexAttr.count; i += 3) {
      const i0 = indexAttr.getX(i);
      const i1 = indexAttr.getX(i + 1);
      const i2 = indexAttr.getX(i + 2);

      stl += `  facet normal ${getNormal(i0)}\n`;
      stl += `    outer loop\n`;
      stl += `      vertex ${getVertex(i0)}\n`;
      stl += `      vertex ${getVertex(i1)}\n`;
      stl += `      vertex ${getVertex(i2)}\n`;
      stl += `    endloop\n`;
      stl += `  endfacet\n`;
    }
  }

  stl += `endsolid ${objectName.replace(/[^a-zA-Z0-9_]/g, '_')}\n`;
  return stl;
}

/**
 * Triggers a direct browser file download of a Blob
 */
export function triggerFileDownload(content: string, filename: string, mimeType = 'text/plain') {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
