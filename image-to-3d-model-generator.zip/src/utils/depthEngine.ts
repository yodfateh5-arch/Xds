import * as THREE from 'three';
import { AIAnalysisResult, Model3DStats, ModelGenerationConfig } from '../types';

export interface ProcessedImageData {
  width: number;
  height: number;
  depthArray: Float32Array;
  colorArray: Uint8ClampedArray;
  normalTexture: THREE.CanvasTexture;
  diffuseTexture: THREE.CanvasTexture;
}

/**
 * Rasterizes any image (including SVG, blob, or data URL) to standard JPEG Base64 for AI vision models
 */
export async function rasterizeImageToBase64(
  imageSrc: string,
  maxWidth = 512,
  maxHeight = 512
): Promise<{ base64: string; mimeType: string }> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      let w = img.width || 400;
      let h = img.height || 400;
      if (w > maxWidth || h > maxHeight) {
        if (w > h) {
          h = Math.max(1, Math.round((h * maxWidth) / w));
          w = maxWidth;
        } else {
          w = Math.max(1, Math.round((w * maxHeight) / h));
          h = maxHeight;
        }
      }
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, w);
      canvas.height = Math.max(1, h);
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        const parts = dataUrl.split(',');
        resolve({ base64: parts[1] || '', mimeType: 'image/jpeg' });
        return;
      }
      resolve({ base64: '', mimeType: 'image/jpeg' });
    };
    img.onerror = () => {
      resolve({ base64: '', mimeType: 'image/jpeg' });
    };
    img.src = imageSrc;
  });
}

/**
 * Loads an image from URL or base64 and extracts pixel data + normal map
 */
export async function processImageForDepth(
  imageSrc: string,
  resolution: 'normal' | 'high'
): Promise<ProcessedImageData> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      // Determine grid dimensions based on resolution
      const maxDim = resolution === 'high' ? 120 : 80;
      let targetW = maxDim;
      let targetH = maxDim;

      if (img.width > img.height) {
        targetH = Math.max(20, Math.round((img.height / img.width) * maxDim));
      } else {
        targetW = Math.max(20, Math.round((img.width / img.height) * maxDim));
      }

      const canvas = document.createElement('canvas');
      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) {
        reject(new Error('Canvas 2D context unavailable'));
        return;
      }

      // Draw and sample
      ctx.drawImage(img, 0, 0, targetW, targetH);
      const imgData = ctx.getImageData(0, 0, targetW, targetH);
      const data = imgData.data;

      const numPixels = targetW * targetH;
      const depthArray = new Float32Array(numPixels);

      // Estimate background color from corners
      const cornerIdxs = [0, (targetW - 1) * 4, (targetW * (targetH - 1)) * 4, (numPixels - 1) * 4];
      let bgR = 0, bgG = 0, bgB = 0;
      for (const idx of cornerIdxs) {
        bgR += data[idx];
        bgG += data[idx + 1];
        bgB += data[idx + 2];
      }
      bgR /= 4;
      bgG /= 4;
      bgB /= 4;

      // Center of canvas for spherical/cylindrical falloff
      const centerX = targetW / 2;
      const centerY = targetH / 2;
      const maxRadius = Math.sqrt(centerX * centerX + centerY * centerY);

      // Compute depth based on luminance, distance from bg, and radial envelope
      for (let y = 0; y < targetH; y++) {
        for (let x = 0; x < targetW; x++) {
          const idx = (y * targetW + x) * 4;
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];
          const a = data[idx + 3] / 255.0;

          // Perceptual luminance
          const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0;

          // Color distance from background
          const bgDist = Math.sqrt(
            Math.pow(r - bgR, 2) + Math.pow(g - bgG, 2) + Math.pow(b - bgB, 2)
          ) / 441.67; // max distance is sqrt(255^2*3)

          // Radial dome factor to give volume curvature
          const distCenter = Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2));
          const radialFactor = Math.max(0, 1.0 - Math.pow(distCenter / maxRadius, 1.6));

          // Combine factors: foregroundness * depth
          const isForeground = a > 0.1 && (bgDist > 0.12 || lum > 0.1);
          if (isForeground) {
            // Enhanced depth with smooth dome bulge + luminance features
            const depth = (lum * 0.45 + bgDist * 0.35 + radialFactor * 0.35) * a;
            depthArray[y * targetW + x] = Math.max(0.08, Math.min(1.0, depth));
          } else {
            depthArray[y * targetW + x] = 0.0;
          }
        }
      }

      // Create Normal Map Canvas for realistic lighting reflections
      const normalCanvas = document.createElement('canvas');
      normalCanvas.width = targetW;
      normalCanvas.height = targetH;
      const normCtx = normalCanvas.getContext('2d');
      if (normCtx) {
        const normImgData = normCtx.createImageData(targetW, targetH);
        const normData = normImgData.data;

        for (let y = 0; y < targetH; y++) {
          for (let x = 0; x < targetW; x++) {
            const i = y * targetW + x;
            const left = x > 0 ? depthArray[y * targetW + (x - 1)] : depthArray[i];
            const right = x < targetW - 1 ? depthArray[y * targetW + (x + 1)] : depthArray[i];
            const up = y > 0 ? depthArray[(y - 1) * targetW + x] : depthArray[i];
            const down = y < targetH - 1 ? depthArray[(y + 1) * targetW + x] : depthArray[i];

            // Sobel / central difference gradient
            const dx = (left - right) * 2.5;
            const dy = (up - down) * 2.5;
            const dz = 1.0;

            const len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            const nx = (dx / len) * 0.5 + 0.5;
            const ny = (dy / len) * 0.5 + 0.5;
            const nz = (dz / len) * 0.5 + 0.5;

            const outIdx = i * 4;
            normData[outIdx] = Math.round(nx * 255);
            normData[outIdx + 1] = Math.round(ny * 255);
            normData[outIdx + 2] = Math.round(nz * 255);
            normData[outIdx + 3] = 255;
          }
        }
        normCtx.putImageData(normImgData, 0, 0);
      }

      const diffuseTexture = new THREE.CanvasTexture(canvas);
      diffuseTexture.colorSpace = THREE.SRGBColorSpace;
      diffuseTexture.minFilter = THREE.LinearFilter;
      diffuseTexture.magFilter = THREE.LinearFilter;

      const normalTexture = new THREE.CanvasTexture(normalCanvas);
      normalTexture.minFilter = THREE.LinearFilter;
      normalTexture.magFilter = THREE.LinearFilter;

      resolve({
        width: targetW,
        height: targetH,
        depthArray,
        colorArray: data,
        normalTexture,
        diffuseTexture,
      });
    };
    img.onerror = () => reject(new Error('Failed to load image for 3D processing'));
    img.src = imageSrc;
  });
}

/**
 * Builds a watertight volumetric 3D mesh (Front surface + Back surface + Connecting rim)
 */
export function generateVolumetricMesh(
  processed: ProcessedImageData,
  config: ModelGenerationConfig,
  aiAnalysis?: AIAnalysisResult | null
): { mesh: THREE.Mesh; stats: Model3DStats } {
  const { width: W, height: H, depthArray } = processed;
  const depthScale = (aiAnalysis?.depthScale || 1.2) * config.depthIntensity * 1.5;
  const bevel = config.bevelAmount || 0.3;

  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  const aspect = W / H;
  const sizeX = 4.0;
  const sizeY = 4.0 / aspect;

  // 1. FRONT SURFACE VERTICES
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const u = x / (W - 1);
      const v = 1.0 - y / (H - 1);

      const px = (u - 0.5) * sizeX;
      const py = (v - 0.5) * sizeY;

      const d = depthArray[y * W + x];
      // Front Z displacement
      const pz = d > 0.05 ? d * depthScale : 0;

      positions.push(px, py, pz);
      uvs.push(u, v);
    }
  }

  // 2. FRONT SURFACE INDICES
  for (let y = 0; y < H - 1; y++) {
    for (let x = 0; x < W - 1; x++) {
      const i0 = y * W + x;
      const i1 = y * W + (x + 1);
      const i2 = (y + 1) * W + x;
      const i3 = (y + 1) * W + (x + 1);

      indices.push(i0, i2, i1);
      indices.push(i1, i2, i3);
    }
  }

  // 3. BACK SURFACE (if doubleSided is enabled)
  if (config.doubleSided) {
    const offset = positions.length / 3;

    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const u = x / (W - 1);
        const v = 1.0 - y / (H - 1);

        const px = (u - 0.5) * sizeX;
        const py = (v - 0.5) * sizeY;

        const d = depthArray[y * W + x];
        // Mirror back Z displacement with bevel tapering
        const pz = d > 0.05 ? -d * depthScale * bevel : -0.1;

        positions.push(px, py, pz);
        uvs.push(u, v);
      }
    }

    // Back indices (reversed winding order for outward normals)
    for (let y = 0; y < H - 1; y++) {
      for (let x = 0; x < W - 1; x++) {
        const i0 = offset + (y * W + x);
        const i1 = offset + (y * W + (x + 1));
        const i2 = offset + ((y + 1) * W + x);
        const i3 = offset + ((y + 1) * W + (x + 1));

        indices.push(i0, i1, i2);
        indices.push(i1, i3, i2);
      }
    }

    // 4. CONNECTING RIM / WALLS (Watertight boundary)
    // Top border (y = 0)
    for (let x = 0; x < W - 1; x++) {
      const f0 = x;
      const f1 = x + 1;
      const b0 = offset + x;
      const b1 = offset + x + 1;
      indices.push(f0, f1, b0);
      indices.push(f1, b1, b0);
    }
    // Bottom border (y = H - 1)
    for (let x = 0; x < W - 1; x++) {
      const f0 = (H - 1) * W + x;
      const f1 = (H - 1) * W + x + 1;
      const b0 = offset + (H - 1) * W + x;
      const b1 = offset + (H - 1) * W + x + 1;
      indices.push(f0, b0, f1);
      indices.push(f1, b0, b1);
    }
    // Left border (x = 0)
    for (let y = 0; y < H - 1; y++) {
      const f0 = y * W;
      const f1 = (y + 1) * W;
      const b0 = offset + y * W;
      const b1 = offset + (y + 1) * W;
      indices.push(f0, b0, f1);
      indices.push(f1, b0, b1);
    }
    // Right border (x = W - 1)
    for (let y = 0; y < H - 1; y++) {
      const f0 = y * W + (W - 1);
      const f1 = (y + 1) * W + (W - 1);
      const b0 = offset + y * W + (W - 1);
      const b1 = offset + (y + 1) * W + (W - 1);
      indices.push(f0, f1, b0);
      indices.push(f1, b1, b0);
    }
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();

  // Create material based on shading and config
  const roughness = aiAnalysis?.roughness ?? 0.4;
  const metalness = aiAnalysis?.metalness ?? 0.15;

  let material: THREE.Material;

  if (config.shadingMode === 'clay') {
    material = new THREE.MeshStandardMaterial({
      color: 0xd4d4d8,
      roughness: 0.8,
      metalness: 0.05,
      wireframe: config.wireframe,
      flatShading: config.mode === 'lowpoly',
    });
  } else if (config.shadingMode === 'normal') {
    material = new THREE.MeshNormalMaterial({
      wireframe: config.wireframe,
      flatShading: config.mode === 'lowpoly',
    });
  } else {
    // Textured PBR material
    material = new THREE.MeshStandardMaterial({
      map: processed.diffuseTexture,
      normalMap: processed.normalTexture,
      normalScale: new THREE.Vector2(0.8, 0.8),
      roughness,
      metalness,
      wireframe: config.wireframe,
      flatShading: config.mode === 'lowpoly',
      side: config.doubleSided ? THREE.DoubleSide : THREE.FrontSide,
    });
  }

  const mesh = new THREE.Mesh(geometry, material);
  mesh.castShadow = true;
  mesh.receiveShadow = true;

  // Center geometry
  geometry.computeBoundingBox();
  const bb = geometry.boundingBox!;
  const w = bb.max.x - bb.min.x;
  const h = bb.max.y - bb.min.y;
  const d = bb.max.z - bb.min.z;

  const stats: Model3DStats = {
    verticesCount: positions.length / 3,
    trianglesCount: indices.length / 3,
    width: Math.round(w * 10) / 10,
    height: Math.round(h * 10) / 10,
    depth: Math.round(d * 10) / 10,
    estimatedPrintWeightGram: Math.round((w * h * d * 0.45) * 10) / 10,
  };

  return { mesh, stats };
}

/**
 * Builds an interactive 3D Voxel Sculpture from the image
 */
export function generateVoxelMesh(
  processed: ProcessedImageData,
  config: ModelGenerationConfig
): { group: THREE.Group; stats: Model3DStats } {
  const { width: W, height: H, depthArray, colorArray } = processed;
  const group = new THREE.Group();

  // Grid step
  const step = 2; // sample every 2 pixels for performance
  const voxelSize = 0.08;
  const depthScale = config.depthIntensity * 1.6;

  const aspect = W / H;
  const sizeX = 4.0;
  const sizeY = 4.0 / aspect;

  const boxGeo = new THREE.BoxGeometry(voxelSize * 0.95, voxelSize * 0.95, voxelSize * 0.95);

  // Count active voxels
  const voxelData: Array<{ x: number; y: number; z: number; r: number; g: number; b: number }> = [];

  for (let y = 0; y < H; y += step) {
    for (let x = 0; x < W; x += step) {
      const idx = y * W + x;
      const d = depthArray[idx];

      if (d > 0.08) {
        const u = x / (W - 1);
        const v = 1.0 - y / (H - 1);

        const px = (u - 0.5) * sizeX;
        const py = (v - 0.5) * sizeY;

        const colorIdx = idx * 4;
        const r = colorArray[colorIdx] / 255;
        const g = colorArray[colorIdx + 1] / 255;
        const b = colorArray[colorIdx + 2] / 255;

        // Number of vertical layers in depth
        const layers = Math.max(1, Math.round(d * 8 * depthScale));
        for (let l = 0; l < layers; l++) {
          const pz = (l - layers / 2) * voxelSize;
          voxelData.push({ x: px, y: py, z: pz, r, g, b });
        }
      }
    }
  }

  const count = voxelData.length;
  const instancedMesh = new THREE.InstancedMesh(
    boxGeo,
    config.shadingMode === 'clay'
      ? new THREE.MeshStandardMaterial({ color: 0xd4d4d8, roughness: 0.7 })
      : new THREE.MeshStandardMaterial({ roughness: 0.5, metalness: 0.1 }),
    count
  );
  instancedMesh.castShadow = true;
  instancedMesh.receiveShadow = true;

  const matrix = new THREE.Matrix4();
  const color = new THREE.Color();

  for (let i = 0; i < count; i++) {
    const v = voxelData[i];
    matrix.setPosition(v.x, v.y, v.z);
    instancedMesh.setMatrixAt(i, matrix);
    if (config.shadingMode !== 'clay') {
      color.setRGB(v.r, v.g, v.b);
      instancedMesh.setColorAt(i, color);
    }
  }

  if (instancedMesh.instanceColor) {
    instancedMesh.instanceColor.needsUpdate = true;
  }
  instancedMesh.instanceMatrix.needsUpdate = true;
  group.add(instancedMesh);

  const stats: Model3DStats = {
    verticesCount: count * 8,
    trianglesCount: count * 12,
    width: sizeX,
    height: sizeY,
    depth: Math.round(voxelSize * 8 * depthScale * 10) / 10,
    estimatedPrintWeightGram: Math.round(count * 0.05 * 10) / 10,
  };

  return { group, stats };
}
