export type MeshMode = 'volumetric' | 'relief' | 'voxels' | 'lowpoly';

export type ShadingMode = 'textured' | 'clay' | 'normal' | 'wireframe';

export type LightingPreset = 'studio' | 'warm' | 'cyber' | 'daylight';

export interface AIAnalysisResult {
  objectName: string;
  category: string;
  shapeType: string;
  roughness: number;
  metalness: number;
  depthScale: number;
  symmetry: string;
  description: string;
  dominantColors: string[];
  components?: Array<{
    name: string;
    relativeSize: number;
    depthFactor: number;
  }>;
}

export interface Model3DStats {
  verticesCount: number;
  trianglesCount: number;
  width: number;
  height: number;
  depth: number;
  estimatedPrintWeightGram?: number;
}

export interface ModelGenerationConfig {
  mode: MeshMode;
  depthIntensity: number;
  bevelAmount: number;
  meshResolution: 'normal' | 'high';
  doubleSided: boolean;
  wireframe: boolean;
  shadingMode: ShadingMode;
  lighting: LightingPreset;
  autoRotate: boolean;
  rotationSpeed: number;
}

export interface SampleImage {
  id: string;
  title: string;
  titleUrdu: string;
  category: string;
  dataUrl: string;
}
